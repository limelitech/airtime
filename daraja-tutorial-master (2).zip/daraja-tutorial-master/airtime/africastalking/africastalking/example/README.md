# Example


**Run**

First, make sure to put your sandbox api key in `index.php`, then:

```bash
$ composer install
$ php -S localhost:9090
$ # open http://localhost:9090
```