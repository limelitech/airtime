<?php

session_name("limelite_airtime");
session_start();

  date_default_timezone_set('Africa/Nairobi');

  # access token
  $consumerKey = 'CUoUBZeQWM9gTY1tAAOPZQ2DkzDOELtx'; //Fill with your app Consumer Key
  $consumerSecret = 'b9yopkNB8nb74BaG'; // Fill with your app Secret

  # define the variales
  # provide the following details, this part is found on your test credentials on the developer account
  $BusinessShortCode = '6437000';
  $Passkey = '9f699879203c3f5dc4904236132eb11c6646a2be69162726a60a1ea744b2867a';  
  
  /*
    This are your info, for
    $PartyA should be the ACTUAL clients phone number or your phone number, format 2547********
    $AccountRefference, it maybe invoice number, account number etc on production systems, but for test just put anything
    TransactionDesc can be anything, probably a better description of or the transaction
    $Amount this is the total invoiced amount, Any amount here will be 
    actually deducted from a clients side/your test phone number once the PIN has been entered to authorize the transaction. 
    for developer/test accounts, this money will be reversed automatically by midnight.
  */
  
  $AccountReference = 'Limelite';
  $TransactionDesc = 'Limelite Tech Solutions';
 
  # Get the timestamp, format YYYYmmddhms -> 20181004151020
  $Timestamp = date('YmdHis');

  $Checkout=$_SESSION["CHECKOUT"];
  $CheckoutRequestID = $Checkout;
  
  # Get the base64 encoded string -> $password. The passkey is the M-PESA Public Key
  $Password = base64_encode($BusinessShortCode.$Passkey.$Timestamp);

  # header for access token
  $headers = ['Content-Type:application/json; charset=utf8'];

    # M-PESA endpoint urls
  $access_token_url = 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
  $initiate_url = 'https://api.safaricom.co.ke/mpesa/stkpushquery/v1/query';

  # callback url
  $CallBackURL = 'https://morning-basin-87523.herokuapp.com/callback_url.php';  

  $curl = curl_init($access_token_url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
  curl_setopt($curl, CURLOPT_HEADER, FALSE);
  curl_setopt($curl, CURLOPT_USERPWD, $consumerKey.':'.$consumerSecret);
  $result = curl_exec($curl);
  $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
  $result = json_decode($result);
  $access_token = $result->access_token;  
  curl_close($curl);

  # header for stk push
  $stkheader = ['Content-Type:application/json','Authorization:Bearer '.$access_token];

  # initiating the transaction
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $initiate_url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $stkheader); //setting custom header

  $curl_post_data = array(
    'BusinessShortCode' => $BusinessShortCode,
    'Password' => $Password,
    'Timestamp' => $Timestamp,
    'CheckoutRequestID' => $CheckoutRequestID
  );

$data_string = json_encode($curl_post_data);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
$curl_response = curl_exec($curl);
$data_to = json_decode($curl_response);
if (isset($data_to->ResultCode)) {
  $ResultCode = $data_to->ResultCode;
  if ($ResultCode == '1037') {
    echo "<script>alert('1037 Timeout in completing transaction!!');location.href='index.php';</script>";
  } elseif ($ResultCode == '1032') {
    echo "<script>alert('1032 Transaction  has cancelled by user!!');location.href='index.php';</script>";
  } elseif ($ResultCode == '1') {
    echo "<script>alert('1 The balance is insufficient for the transaction!!');location.href='index.php';</script>";
    //$massage = "1 The balance is insufficient for the transaction";
  } elseif ($ResultCode == '0') {
    echo "<script>alert('1037 Timeout in completing transaction!!');location.href='index.php';</script>";
    //$massage = "0 The transaction is successfully";
  }
}

//echo $massage;
?>
