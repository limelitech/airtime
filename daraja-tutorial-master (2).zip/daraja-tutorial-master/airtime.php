<?php
require 'airtime/autoload.php';

//$dbServername = "localhost";
//$dbUsername = "katheimc_litech";
//$dbPassword = "katheim";
//$dbName = "katheimc_litech";

//$connect = new mysqli($dbServername, $dbUsername, $dbPassword, $dbName);


use AfricasTalking\SDK\AfricasTalking;

if(isset($_POST['submit'])) {
//insert data from form
 $phone = $_POST['phone'];
 $amount = $_POST['amount'];
 $currency = 'KES';
 //$email = $_SESSION["EMAIL"];
 //$fname = $_SESSION["FNAME"];
 //$mname = $_SESSION["MNAME"];
 //$lname = $_SESSION["LNAME"];
 date_default_timezone_set("Africa/Nairobi");
 $date = date('Y-m-d H:i:s');
  
  $rec = rand(10000000,99999999);
    
  
// Set your app credentials
$user = "litechnologii";
$api = "02f83b4da505ea04612ca34b324c5180aecbb7fa28be188c74432cc30b455e88";
  
 //$user = "sandbox";
 //$api = "c00f3217b52efbc5179edf2bebc8496e98098a61c26c58ff11f8f7d5f762fd39";

// Initialize the SDK
$AT       = new AfricasTalking($user, $api);

// Get the airtime service
$airtime  = $AT->airtime();

// Set the phone number, currency code and amount in the format below
$recipients = [[
    "phoneNumber"  => "$phone",
    "currencyCode" => "$currency",
    "amount"       => "$amount"
]];

try {
    // That's it, hit send and we'll take care of the rest
    $results = $airtime->send([
        "recipients" => $recipients
    ]);
    
      
    $data = json_encode($results, TRUE);
    $fetch = json_decode($data, TRUE);
  print_r($fetch);
  if ($fetch['data']['errorMessage'] === 'A duplicate request was received within the last 5 minutes') {
            echo "<script>alert('A duplicate request was received within the last 5 minutes!');location.href='index.php';</script>";
        } elseif ($fetch['data']['errorMessage'] === 'Cross Country Request not Permitted'){
            echo "<script>alert('Cross Country Request not Permitted!!');location.href='index.php;</script>";
        } elseif ($fetch['data']['errorMessage'] === 'Insufficient Credit'){
            echo "<script>alert('Technical Error contact sales via +254704815319!!');location.href='index.php;</script>";
        } elseif ($fetch['data']['errorMessage'] === 'Value Outside The Allowed Limits'){
            echo "<script>alert('Value Outside The Allowed Limits!!');location.href='index.php;</script>";
        } elseif ($fetch['data']['responses']['0']['errorMessage'] === 'Invalid phone number or amount'){
            echo "<script>alert('invalid number/amount enter phone number in this format +254704815319!!');location.href='index.php;</script>";
        } elseif ($fetch['data']['responses']['0']['errorMessage'] === 'Insufficient Credit'){
            echo "<script>alert('Insufficient Credit!!');location.href='index.php;</script>";
        } elseif ($fetch['data']['responses']['0']['status'] === 'Failed'){
            echo "<script>alert('Technical Error Contact Support team!!');location.href='index.php;</script>";
        } elseif ($fetch['data']['responses']['0']['errorMessage'] === 'Value Outside The Allowed Limits'){
            echo "<script>alert('You can not purchase airtime below KES10!!');location.href='index.php;</script>";
        }elseif ($fetch['data']['errorMessage'] === 'None'){
        // mysqli_query($connect, "INSERT INTO `airtime`(`id`, `fname`, `mname`, `lname`, `email`, `status`, `amount`, `currency`, `phone`, `payersID`, `date`) 
   // VALUES (0,'$fname','$mname','$lname','$email','success','$amount','$currency','$phone','$rec','$date')");
         echo "<script>alert('Airtime sold Successfull!!');location.href='index.php';</script>";
        }else{
         print_r($fetch);
        echo "<script>alert('Contact Support Team!!');location.href='index.php</script>";
  }
    
} catch(Exception $e) {
   echo "Error: ".$e->getMessage();
}
}
?>